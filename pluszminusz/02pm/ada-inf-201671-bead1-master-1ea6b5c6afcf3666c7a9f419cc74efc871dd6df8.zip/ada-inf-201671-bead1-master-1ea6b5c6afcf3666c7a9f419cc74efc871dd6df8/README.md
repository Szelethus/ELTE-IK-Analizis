*A megoldást egyetlen, `.zip` kiterjesztésű tömörített állományban kell beadni,
amely csak és kizárólag forrásokat tartalmazhat, a
feladat leírása szerint megkövetelt könyvtárszerkezetben.  A beadási hely
Linux alatt az* `smb://nas2.inf.elte.hu/zh/ada` *Windows alatt a*
`\\nas2.inf.elte.hu\zh\ada` *mappa.

# Rendezés egy kupac segítségével

A kupac (heap) egy
olyan bináris fa, amelynek minden csúcsára igaz, hogy kisebb, mint a gyermekei.
(Egész pontosan ezeket a kupacokat min-kupacnak nevezzük. Vegyük észre, hogy a
definíció értelmében a min-kupac legkisebb eleme a gyökérben van!) Olyan kupacot
kell most megvalósítani, ami balra tömörített (kvázi-teljes) fa, azaz a
legalsó szint kivételével minden szint teljesen kitöltött, és a legalsó szinten
is csak a jobb széléről hiányozhatnak csúcsok. Példa egy egész számokat
tartalmazó min-kupacra:

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                       1
                    /      \
                 3            2
               /   \        /   \
             6       5    10      4
            / \     /
           8   9   7

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

> -----------------
>
> ### Bináris fa fogalma
> A bináris fa struktúrája lényegében a matematikai fa-fogalommal írható le.
> Az a definíció, amelyre az előző pontban utaltunk, speciális gráfként
> határozza meg a bináris fát. Eszerint a fa olyan körmentes irányított
> gráf, amelyre igazak az alábbiak: pontosan egy csúcsba nem vezet él (ez a gyökér);
> a többi csúcsba pontosan egy él vezet és minden csúcs elérhető a gyökérből,
> mégpedig egyértelműen. Az egyes csúcsokból kivezető élek száma minden fára
> korlátos (r>0). Az elnevezése ekkor: r-áris fa. Az r = 2 érték esetén beszélünk
> bináris fákról!
>
> Forrás : Dr. Fekete István Algoritmusok jegyzet (7. jegyzet: Bináris fák)
>
> -----------------

Egy ilyen adatszerkezetet kényelmesen megvalósíthatunk egy tömb segítségével.
A tömb mérete korlátozza, hogy mekkora fát ábrázolhatunk vele: a fa mérete
nem nőhet nagyobbra, mint a tömb. A tömb első valahány eleme (azaz a tömb egy
prefixe) a kupac elemeit fogja tárolni sorfolytonos módon, azaz a fenti példát
egy 30 hosszú tömbben reprezentálnánk úgy, hogy a tömb első 10 eleme
1,3,2,6,5,10,4,8,9,7. Ebben a reprezentációban az **1** index felel meg a kupac
gyökerének, és az **i** indexű csúcs gyermekei a **2i** és a **2i+1**
indexű csúcsok lesznek. (Ebből következően az **i** indexű csúcs szülője
az **i/2** indexű csúcs, ahol a **/** most a nulla felé kerekítő egész osztást
jelenti.)


## Heap adattípus

Készítsd el a `Heap` (azaz kupac) generikus absztrakt adattípust.
Ábrázoljuk a kupacot diszkriminánsos rekorddal; a diszkrimináns a kupac
kapacitása, és a rekordban tároljuk még az elemek kapacitás méretű, 1-től
indexelt tömbjét, valamint a kupac aktuális méretét.

Készítsük el a kupac típus műveleteit is, egyelőre csak valami dummy
implementációval, csak hogy forduljon a kód.

- `Size`: a kupac mérete
- `Insert`: a kupacba beszúr egy elemet
  (`Heap_Exception` kivételt vált ki, ha nem fér több elem a kupacba)
- `Extract`: kitörli a kupac gyökérelemét, és visszaadja
  (`Heap_Exception` kivételt vált ki üres kupac esetén)

Készíts főprogramot a kupac kipróbálására!


## Kupacműveletek

A kupacba beszúró `Insert` művelet megvalósítása a következő. Tegyük be az
új elemet legutolsó elemként, majd buborékoltassuk fel a helyére az
`Up_Heap` művelettel! Jelölje `Size` az új elemmel kibővített kupac méretét.
Jelölje `Data` a tömböt. Az új elem, amit most beszúrtunk, és ami most még
lehet, hogy elrontja a kupac-tulajdonságot, a `Data(Size)` lesz.

~~~~~~~~~~
                           Up_Heap
+-------------------------------------------------------------+
| K, Go := Size, True                                         |
|-------------------------------------------------------------+
|    Go /\ K > 1                                              |
|   +---------------------------------------------------------+
|   |i\                   Data(K) < Data(K/2)               /h|    
|   |------------------------------------------+--------------+
|   | Data(K), Data(K/2) := Data(K/2), Data(K) | Go := False  |
|   | K := K/2                                 |              |
+---+------------------------------------------+--------------+
~~~~~~~~~~

A kupac legkisebb elemét eltávolító `Extract` művelet megvalósítása a
következő. Adjuk vissza a `Data(1)` értékét, írjuk felül ezt az első
elemet a kupac utolsó elemével (azaz a `Data(Size)` értékkel), és
csökkentsük a `Size` értékét is eggyel. Most a kupac gyökerében nem
biztos, hogy teljesül a kupac-tulajdonság, ezért a `Down_Heap` művelettel
buborékoltassuk le a helyére a gyökérben lévő elemet.

~~~~~~~~~~
                                 Down_Heap
+------------------------------------------------------------------------+
| K, Go, Smallest := 1, True, 1                                          |
|------------------------------------------------------------------------+
|    Go                                                                  |
|   +--------------------------------------------------------------------+
|   |i\                 2*K <= Size /\ Data(2*K) < Data(K)             /h|    
|   |--------------------------------------------+-----------------------+
|   | Smallest := 2*K                            |  skip                 |
|   +--------------------------------------------+-----------------------+
|   |i\          2*K+1 <= Size /\ Data(2*K+1) < Data(Smallest)         /h|    
|   |--------------------------------------------+-----------------------+
|   | Smallest := 2*K+1                          |  skip                 |
|   +--------------------------------------------+-----------------------+
|   |i\                           Smallest > K                         /h| 
|   |-----------------------------------------------------+--------------+
|   | Data(K), Data(Smallest) := Data(Smallest), Data(K)  | Go := False  |
|   | K := Smallest                                       |              |
+---+-----------------------------------------------------+--------------+
~~~~~~~~~~

Teszteld a kupacműveleteket a főprogramban!


## Rendezés

Készíts generikus `Sort` eljárást, amelyet paraméterezni lehet egy tömb
típussal (valamint annak index- és elemtípusával) is. A `Sort` kap egy
tömböt, és lerendezi, mégpedig olyan módon, hogy a tömb elemeit bepakolja
egy kupacba, majd a kupacból mindig kivéve a legkisebb elemet, visszatölti
az elemeket a tömbbe.

Készíts főprogramot a rendezés kipróbálására!


## További kupacműveletek

Valósítsd meg az egyenlőségvizsgálat műveletét kupacokra!
Két kupac egyenlő, ha ugyanannyi elemet tartalmaznak, és minden
tartalmazott elemük egyenlő. (A kupacok kapacitása lehet különböző!)

Készíts generikus `For_Each` eljárást a sabloncsomagban, amely egy
kupac minden elemére alkalmaz egy paraméterként kapott eljárást!
